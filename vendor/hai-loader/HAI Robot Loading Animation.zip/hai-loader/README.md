# hai-loader

3D HAI Robotics loading screen as a framework-agnostic web component.
Its only dependency is `three`.

## Install

1. Copy `hai-loader.js` into your app (e.g. `src/components/hai-loader.js`).
2. Install three: `npm i three`.

## Use

### Plain HTML / any bundler (Vite, Next, etc.)
```js
import './components/hai-loader.js';
```
```html
<hai-loader></hai-loader>
```

### React
```jsx
import './components/hai-loader.js';

export function AppLoader({ loading, children }) {
  return loading ? <hai-loader style={{ position: 'fixed', inset: 0 }} background="#fff" /> : children;
}
```
For Next.js, import it only on the client (it uses WebGL):
```jsx
'use client';
import { useEffect } from 'react';
export default function Loader() {
  useEffect(() => { import('./hai-loader.js'); }, []);
  return <hai-loader style={{ position: 'fixed', inset: 0 }} />;
}
```
TypeScript: add `declare namespace JSX { interface IntrinsicElements { 'hai-loader': any } }` to a `.d.ts` file.

## Options

| Attribute    | Default                                  | Notes                                 |
|--------------|------------------------------------------|---------------------------------------|
| `background` | transparent                              | any CSS color                         |
| `footer`     | `HAI Robotics · Intelligent Automation`  | `footer=""` hides it                  |
| `no-status`  | –                                        | robot only, no text/bar               |
| `speed`      | `1`                                      | animation speed multiplier            |

Custom copy:
```js
document.querySelector('hai-loader').messages = [
  ['Syncing inventory', 'Counting every tote'],
  ['Almost there', 'Gently lowering expectations'],
];
```

- Sizes to its container (min-height 420px).
- Stops rendering when removed from the DOM; call `el.dispose()` to free GPU memory.
- Respects `prefers-reduced-motion`.

## Demo
Serve the folder (e.g. `npx serve`) and open `demo.html`.
